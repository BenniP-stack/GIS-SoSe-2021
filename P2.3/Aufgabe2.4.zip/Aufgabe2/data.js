"use strict";
var Aufgabe2;
(function (Aufgabe2) {
    Aufgabe2.parts = {
        heads: [
            "images/Heads/kopf.jpg",
            "images/Heads/kageyama1.jpg",
            "images/Heads/kageyama2.jpg"
        ],
        torsos: [
            "images/Torso/Cursed_Torso.jpg",
            "images/Torso/Cursed_Torso2.jpg",
            "images/Torso/Cursed_Torso3.jpg"
        ],
        legs: [
            "images/Legs/Cursed_Legs.jpg",
            "images/Legs/Cursed_Legs2.jpg",
            "images/Legs/Cursed_Legs3.jpg"
        ]
    };
    Aufgabe2.data = JSON.stringify(Aufgabe2.parts);
    /*export let bodyJSON: string = `{
        "heads":[
            "image": "images/Heads/kopf.jpg",
            "image": "images/Heads/kageyama1.jpg",
            "image": "images/Heads/kageyama2.jpg"
        ]
        "torsos":[
            "image": "images/Torso/Cursed_Torso",
            "image": "images/Torso/Cursed_Torso2",
            "image": "images/Torso/Cursed_Torso3"
        ]
        "legs":[
            "image": "images/Legs/Cursed_Legs",
            "image": "images/Legs/Cursed_Legs2",
            "image": "images/Legs/Cursed_Legs3"
        ]
    }`;
    export let myObj: HumanBody = JSON.parse(bodyJSON);
*/
})(Aufgabe2 || (Aufgabe2 = {}));
//# sourceMappingURL=data.js.map