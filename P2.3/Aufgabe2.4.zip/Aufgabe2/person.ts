interface Person {
    head: string;
    body: string;
    legs: string;
}

interface _head {
    head: string;
}
interface _torso {
    torso: string;
}
interface _legs {
    legs: string;
}
